from flask import Flask, render_template, request, redirect
app = Flask(__name__)  

@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['POST'])         
def checkout():
    count = int(request.form["strawberry"]) + int(request.form["raspberry"]) + int(request.form["blackberry"]) + int(request.form["apple"])
    
    print("Charging " + request.form["first_name"] + " " + request.form["last_name"] + " for " + str(count) + " fruits")
    print("*" * 50)
    print(request.form)
    return render_template("checkout.html", straw_q = request.form["strawberry"], 
    rasp_q = request.form["raspberry"], blackb_q = request.form["blackberry"], 
    apple_q = request.form["apple"], first_name = request.form["first_name"], 
    last_name = request.form["last_name"], student_id = request.form["student_id"],
    counter = count)


@app.route('/fruits')         
def fruits():

    return render_template("fruits.html")

if __name__=="__main__":   
    app.run(debug=True)    